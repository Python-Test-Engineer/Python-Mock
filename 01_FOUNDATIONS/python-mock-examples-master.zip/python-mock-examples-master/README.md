python-mock-examples
====================

Example usage of the python mock library

These are examples, expressed as a passing test suite (`tests.py`), that expand on the existing documentation for mock.

Mock is a library for testing in Python (now in the standard library in Python 3.3+)

https://pypi.python.org/pypi/mock

